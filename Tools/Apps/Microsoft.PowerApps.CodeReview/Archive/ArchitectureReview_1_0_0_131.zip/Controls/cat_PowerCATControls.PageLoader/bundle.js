var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./PageLoader/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./PageLoader/PropertyBagState.ts":
/*!****************************************!*\
  !*** ./PageLoader/PropertyBagState.ts ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.PCFPropertyBagStateManager = void 0; // ParameterState keeps tabs on which values have actually changed\n// Canvas App PCF controls don't get notified of which parameters have chaned\n// Model Driven Apps get passed all parameters on save even if they haven't changed\n\nvar PCFPropertyBagStateManager =\n/** @class */\nfunction () {\n  function PCFPropertyBagStateManager(convertToLocalDate, emmitDebug) {\n    this.emmitDebug = false;\n    this.isCanvas = false;\n    this.updatedValues = {};\n    this.currentValues = {};\n    this.convertToLocalDate = convertToLocalDate;\n    this.emmitDebug = emmitDebug !== null && emmitDebug !== void 0 ? emmitDebug : false;\n    this.isCanvas = window && !window.hasOwnProperty(\"Xrm\");\n  }\n\n  PCFPropertyBagStateManager.prototype.debug = function (message) {\n    if (this.emmitDebug) {\n      console.debug(message);\n    }\n  };\n\n  PCFPropertyBagStateManager.prototype.setAllProperties = function (properties) {\n    // Set the values\n    this.currentValues = {};\n    this.getInboundChangedProperties(properties, Object.keys(properties));\n  };\n\n  PCFPropertyBagStateManager.prototype.updateProperties = function (parameters) {\n    var _a, _b; // Merge the changed values with the existing pending changes\n\n\n    var paramRecord = parameters; // Work out which parameters have changed\n\n    for (var property in paramRecord) {\n      var newValue = paramRecord[property];\n      var oldValue = this.currentValues[property];\n\n      if (newValue instanceof Date) {\n        newValue = (_a = newValue) === null || _a === void 0 ? void 0 : _a.toISOString();\n        oldValue = (_b = oldValue) === null || _b === void 0 ? void 0 : _b.toISOString();\n      }\n\n      if (newValue != oldValue) {\n        this.debug(\"PCF:OUT \" + property + \"=\" + newValue + \" (new)\\nPCF:OUT \" + property + \"=\" + oldValue + \" (old)\");\n        this.updatedValues[property] = paramRecord[property];\n        this.currentValues[property] = paramRecord[property];\n      }\n    }\n  }; // eslint-disable-next-line @typescript-eslint/no-unused-vars\n\n\n  PCFPropertyBagStateManager.prototype.getInboundChangedProperties = function (properties, updatedProperties) {\n    var _a, _b, _c;\n\n    var changedProperties = []; // If in Canvas ignore the updatedProperties since it doesn't return anything helpful\n\n    if (this.isCanvas) updatedProperties = Object.keys(properties);\n\n    for (var _i = 0, updatedProperties_1 = updatedProperties; _i < updatedProperties_1.length; _i++) {\n      var propertyName = updatedProperties_1[_i];\n      var property = properties[propertyName];\n\n      if (property && property.type != undefined) {\n        var skip = false;\n        var newValueRaw = property.raw;\n        var newValueCompare = property.raw;\n        var oldValueCompare = this.currentValues[propertyName]; // Some raw types can't be compared as objects\n\n        switch (property.type) {\n          case \"DataSet\":\n            // Canvas provides a DataSet property of any bound column\n            // since the values are actually in the records, we don't need this\n            skip = true;\n            break;\n\n          case \"\":\n            // eslint-disable-next-line @typescript-eslint/no-explicit-any\n            if (property.records) {\n              // this is a dataset property\n              skip = true;\n            } // Guid/entity id's type == \"\"\n            // The raw value is a Guid object\n\n\n            newValueCompare = property.raw && property.raw.toString(); // eslint-disable-next-line @typescript-eslint/ban-types\n\n            oldValueCompare = (_a = this.currentValues[propertyName]) === null || _a === void 0 ? void 0 : _a.toString();\n            break;\n\n          case \"DateAndTime.DateAndTime\":\n          case \"DateAndTime.DateOnly\":\n            // Adjust for the fact that we get the date values in utc - convert to local time\n            newValueRaw = this.convertToLocalDate(property);\n            newValueCompare = (_b = newValueRaw) === null || _b === void 0 ? void 0 : _b.toISOString();\n            oldValueCompare = (_c = this.currentValues[propertyName]) === null || _c === void 0 ? void 0 : _c.toISOString();\n            break;\n        }\n\n        if (!skip && newValueCompare != oldValueCompare) {\n          this.debug(\"PCF:IN \" + propertyName + \"=\" + newValueCompare + \" (new)\\nPCF:IN \" + propertyName + \"=\" + oldValueCompare + \" (old)\");\n          changedProperties.push(propertyName);\n          this.currentValues[propertyName] = newValueRaw;\n        }\n      }\n    }\n\n    return changedProperties;\n  };\n\n  PCFPropertyBagStateManager.prototype.getOutboundChangedProperties = function () {\n    var pendingChanges = this.updatedValues;\n    this.updatedValues = {};\n    return pendingChanges;\n  };\n\n  return PCFPropertyBagStateManager;\n}();\n\nexports.PCFPropertyBagStateManager = PCFPropertyBagStateManager;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./PageLoader/PropertyBagState.ts?");

/***/ }),

/***/ "./PageLoader/index.ts":
/*!*****************************!*\
  !*** ./PageLoader/index.ts ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.PageLoader = void 0;\n\nvar PropertyBagState_1 = __webpack_require__(/*! ./PropertyBagState */ \"./PageLoader/PropertyBagState.ts\");\n\nvar PageLoader =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function PageLoader() {\n    /** event variables */\n    this.propertyStateManager = new PropertyBagState_1.PCFPropertyBagStateManager(function () {\n      return null;\n    }, false);\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  PageLoader.prototype.init = function (context, notifyOutputChanged, state, container) {\n    this._context = context;\n    this._container = container;\n    this._pageType = context.parameters.pageType.raw;\n    this._customPageName = context.parameters.customPageName.raw;\n    this._entityName = context.parameters.entityName.raw;\n    this._recordId = context.parameters.recordId.raw;\n    this._target = context.parameters.target.raw;\n    this._targetWidth = context.parameters.targetWidth.raw;\n    this._targetHeight = context.parameters.targetHeight.raw;\n    this._position = context.parameters.position.raw;\n    this._title = context.parameters.title.raw;\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  PageLoader.prototype.updateView = function (context) {\n    this._pageType = context.parameters.pageType.raw;\n    this._customPageName = context.parameters.customPageName.raw;\n    this._entityName = context.parameters.entityName.raw;\n    this._recordId = context.parameters.recordId.raw;\n    this._target = context.parameters.target.raw;\n    this._targetWidth = context.parameters.targetWidth.raw;\n    this._targetHeight = context.parameters.targetHeight.raw;\n    this._position = context.parameters.position.raw;\n    this._title = context.parameters.title.raw; //TO DO: Add validation of input.\n\n    var propertiesChanged = this.propertyStateManager.getInboundChangedProperties( // eslint-disable-next-line @typescript-eslint/no-explicit-any\n    context.parameters, context.updatedProperties);\n\n    if (propertiesChanged.length == 0) {\n      return;\n    }\n\n    if (propertiesChanged.length == 1 && propertiesChanged.includes(\"OutPut\")) {\n      return;\n    }\n\n    if (propertiesChanged.includes(\"customPageName\")) {\n      var pageInput = {\n        pageType: this._pageType,\n        name: this._customPageName,\n        entityName: this._entityName,\n        entityId: this._recordId // \"guid-goes-here\"\n\n      };\n      var navigationOptions = {\n        target: this._target,\n        width: this._targetWidth,\n        height: this._targetHeight,\n        position: this._position,\n        title: this._title\n      };\n      console.log(\"Navigation Triggered\");\n\n      this._context.navigation.navigateTo(pageInput,navigationOptions);\n    }\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  PageLoader.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  PageLoader.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n\n  return PageLoader;\n}();\n\nexports.PageLoader = PageLoader;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./PageLoader/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('PowerCATControls.PageLoader', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PageLoader);
} else {
	var PowerCATControls = PowerCATControls || {};
	PowerCATControls.PageLoader = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PageLoader;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}